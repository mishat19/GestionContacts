📘 INSTALLATION DU GESTIONNAIRE DE CONTACTS

Merci d’avoir téléchargé le Gestionnaire de Contacts.

🔧 POUR INSTALLER L’APPLICATION :

1. Ouvrez le dossier de l’installation.
2. Double-cliquez sur le fichier : `setup.exe`
   (Ne lancez pas le fichier `.msi` directement)

Le programme d’installation vérifiera automatiquement si votre ordinateur a tout ce qu’il faut pour faire fonctionner l’application (comme .NET Runtime). Ensuite, il installera l’application sur votre système.

📁 Le logiciel sera installé dans votre répertoire Program Files(x86), et un raccourci sera ajouté sur le bureau.

📤 Pour désinstaller :
Vous pouvez aller dans **Panneau de configuration > Programmes > Désinstaller un programme**, puis désinstaller **Gestionnaire de Contacts**.

---

📌 Si vous avez un fichier `contacts.json` existant, vous pouvez l’importer depuis l’application avec le bouton **Importer fichier**.
Afin que vous puissiez découvrir le fonctionnement du logiciel, une maquette contacts.json est chargée automatiquement.

📍 Les données sont ensuite stockées dans :  
`C:\Users\<VotreNom>\AppData\Roaming\GestionContacts`

---

Merci d'utiliser ce logiciel,
Mishat Ribongrant